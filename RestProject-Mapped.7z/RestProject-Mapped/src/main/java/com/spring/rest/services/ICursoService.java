package com.spring.rest.services;

import java.util.List;

import com.spring.rest.entity.Curso;

public interface ICursoService {

	public List<Curso> findAll();

	public void saveCurso(Curso curso);

	public List<Curso> getCursosProfesor(Long id);

}
