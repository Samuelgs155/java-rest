package com.spring.rest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.rest.dao.IProfesorDao;
import com.spring.rest.entity.Profesor;

@Service
public class ProfesorService implements IProfesorService {

	@Autowired
	private IProfesorDao profesorDao;

	@Override
	@Transactional(readOnly = true)
	public List<Profesor> findAllProfessors() {
		return (List<Profesor>) profesorDao.findAll();
	}

}
