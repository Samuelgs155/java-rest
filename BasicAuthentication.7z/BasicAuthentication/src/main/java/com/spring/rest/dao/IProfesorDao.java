package com.spring.rest.dao;

import org.springframework.data.repository.CrudRepository;

import com.spring.rest.entity.Profesor;

public interface IProfesorDao extends CrudRepository<Profesor, Long> {

}
