package com.spring.rest.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.spring.rest.entity.MovimientoBancario;

public interface IMovimientoBancario extends CrudRepository<MovimientoBancario, Long> {

	public List<MovimientoBancario> findByUserId(Long id);
	
}
