package com.spring.rest.dao;

import org.springframework.data.repository.CrudRepository;

import com.spring.rest.entity.User;

public interface IUserDao extends CrudRepository<User, Long>{

	public User findByUsername(String username);
}
