package com.spring.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestOauth2Application {

	public static void main(String[] args) {
		SpringApplication.run(RestOauth2Application.class, args);
	}

}
