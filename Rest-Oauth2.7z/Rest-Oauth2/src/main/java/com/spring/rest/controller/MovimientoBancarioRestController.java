package com.spring.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.rest.entity.MovimientoBancario;
import com.spring.rest.entity.User;
import com.spring.rest.service.IMovimientoBancarioService;

@RestController
@RequestMapping("/api/oauth2")
public class MovimientoBancarioRestController {

	@Autowired
	private IMovimientoBancarioService moviemientoBancarioService;

	@GetMapping("/movimiento_bancario")
	public ResponseEntity<?> moviemientos() {
		List<MovimientoBancario> movimientosBancarios = moviemientoBancarioService.findAll();
		if(movimientosBancarios != null) {
			return new ResponseEntity<>(movimientosBancarios, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}		
	}
	
	@PostMapping("/movimiento_bancario_user")
	public ResponseEntity<?> movimientoUser(@RequestBody User user) {
		List<MovimientoBancario> movimientosBancarios = moviemientoBancarioService.getMovimientoUser(user.getId());
		if(movimientosBancarios != null) {
			return new ResponseEntity<>(movimientosBancarios, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
}
