package com.spring.rest.services;

import java.util.List;

import com.spring.rest.entity.Lenguaje;

public interface ILenguajeService {

	public List<Lenguaje> findAll();
	
	public void saveLenguaje(Lenguaje lenguaje);
	
	public Lenguaje findLenguajeById(Long id);
}
