package com.spring.rest.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.rest.dao.ICursoDao;
import com.spring.rest.entity.Curso;

@Service
public class CursoService implements ICursoService {

	@Autowired
	private ICursoDao cursoDao;

	@Override
	@Transactional(readOnly=true)
	public List<Curso> findAll() {
		return (List<Curso>) cursoDao.findAll();
	}

	@Override
	@Transactional
	public void saveCurso(Curso curso) {
		cursoDao.save(curso);
	}

	@Override
	@Transactional(readOnly=true)
	public List<Curso> getCursosProfesor(Long id) {		
		return (List<Curso>) cursoDao.findByProfesorId(id);
	}

}
