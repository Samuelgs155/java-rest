package com.spring.rest.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.spring.rest.entity.Curso;

public interface ICursoDao extends CrudRepository<Curso, Long>{

	public List<Curso> findByProfesorId(Long id);
}
