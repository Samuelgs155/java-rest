package com.spring.rest.mapped;

import com.spring.rest.entity.Lenguaje;
import com.spring.rest.entity.Profesor;

public class ProfesorLenguaje {

	private Profesor profesor;
	private Lenguaje lenguaje;

	public Profesor getProfesor() {
		return profesor;
	}

	public void setProfesor(Profesor profesor) {
		this.profesor = profesor;
	}

	public Lenguaje getLenguaje() {
		return lenguaje;
	}

	public void setLenguaje(Lenguaje lenguaje) {
		this.lenguaje = lenguaje;
	}

}
